Minecraft-Launcher-cracked
Online working cracked Minecraft Launcher

Minecraft Launcher cracked online working by me

1. YOU NEED TO DISABLE WINDOWS DEFENDER BEFORE EXECUTING .exe

2. extract the .zip file and execute the "MinecraftLauncher.exe" go trough the setup. It will ask you for email and passwd but you just have to click "continue"

3. select a path you want Minecraft Launcher to be installed. Wait for it to install and click "FINISH"

4. now you are done and have working Minecraft Java/Bedrock